function [a lpcf e] = lpc_mat(x,w,wshft,nlpc,nfft,fs)

wlen = length(w);
nwin = fix((length(x)-wlen+wshft)/wshft);

n = 0;
f = 1;

a    = zeros(nwin,nlpc+1);
lpcf = zeros(nwin,nfft/2);
e    = zeros(nwin,1);
while n+wlen<=length(x)
  s = x(n+(1:wlen)).*w;
  
  [a(f,:) e(f)] = lpc(s,nlpc);
  lpcf(f,:)     = freqz(1,a(f,:),nfft/2,fs)';
  n = n+wshft;
  f = f+1;
end
