% Computing MFCCs 

clc
clear
close all

path('..\..\voicebox',path)

% [x,fs] = wavread('a075Leaf.wav');
[x,fs] = wavread('bdl_arctic_a0013.wav');
x = x(:,1);
x = x';

wlen  = round(25e-3*fs);
wshft = round(1e-3*fs);
win   = hamming(wlen)';
nfft  = 2^10;
nlpc  = 48;
ncep  = 48;
nmel  = 12;

%% Generate STFT, LPC, cepstra, and MFCC for each frame

[stft_x]        = stft(x,win,wshft,nfft);
[a_x lpc_x e_x] = lpc_mat(x,win,wshft,nlpc,nfft,fs);
[c_x cf_x]      = cepstra_mat(x,win,wshft,ncep,nfft,fs);
[mfcc_x]        = mfcc_mat(x,win,wshft,nmel,fs);

% Alternative way of computing MFCCs with voicebox
% '0' means including 0'th order cepstral coefficient (energy)
mfcc_x1 =  melcepst(x, fs, '0');

% Show spectrograms
figure
subplot(411)
imagesc(flipud(log(abs(stft_x(:,1:nfft/2)))')); colorbar
subplot(412)
imagesc(flipud(log(abs(lpc_x(:,1:nfft/2)))')); colorbar
subplot(413)
imagesc(flipud(log(abs(cf_x(:,1:nfft/2)))')); colorbar
subplot(414)
imagesc(flipud(mfcc_x')); colorbar

%% Comparing the two MFCC methods (ignore MFCC_0)

figure
subplot(211)
imagesc(flipud(mfcc_x(:,2:nmel)')); colorbar
subplot(212)
imagesc(flipud(mfcc_x1(:,2:nmel)')); colorbar

%% Show that MFCCs are (approximately) uncorrelated

stft_c = corrcoef(abs(stft_x(:,1:nfft/2)));
cep_c  = corrcoef(c_x(:,1:nfft/2));
mfcc_c = corrcoef(mfcc_x);

figure
subplot(131)
imagesc(stft_c, [-1 1]); colorbar; title('STFT \rho')
subplot(132)
imagesc(cep_c, [-1 1]); colorbar; title('Cepstrum \rho')
subplot(133)
imagesc(mfcc_c, [-1 1]); colorbar; title('MFCC \rho')
