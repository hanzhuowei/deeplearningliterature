% Computing cepstra 

clc
clear
close all

% [x,fs] = wavread('a075Leaf.wav');
[x,fs] = wavread('bdl_arctic_a0013.wav');
x = x(:,1);
x = x';

wlen  = round(25e-3*fs);
wshft = round(1e-3*fs);
win   = hamming(wlen)';
nfft  = 2^10;
nlpc  = 48;
ncep  = 48;

%% Generate STFT, LPC and cepstra for each frame

[stft_x]        = stft(x,win,wshft,nfft);
[a_x lpc_x e_x] = lpc_mat(x,win,wshft,nlpc,nfft,fs);
[c_x cf_x]      = cepstra_mat(x,win,wshft,ncep,nfft,fs);

% Show the three spectra and the cepstrum for a voiced frame
% f = 200;
f = 600;

figure
subplot(211)
plot(log(abs(stft_x(f,1:nfft/2))),'r', 'LineWidth', 1);
hold on
plot(log(abs(lpc_x(f,:)*sqrt(e_x(f)*wlen))),'g', 'LineWidth', 2);
hold on
plot(log(abs(cf_x(f,1:nfft/2))),'b', 'LineWidth', 2);
axis tight
subplot(212)
plot(c_x(f,1:nfft/2),'b');
axis tight

% Show spectrograms

figure
subplot(311)
imagesc(flipud(log(abs(stft_x(:,1:nfft/2)))')); colorbar
subplot(312)
imagesc(flipud(log(abs(lpc_x(:,1:nfft/2)))')); colorbar
subplot(313)
imagesc(flipud(log(abs(cf_x(:,1:nfft/2)))')); colorbar

%% Show that cepstral coefficients are (approximately) uncorrelated

stft_c = corrcoef(abs(stft_x(:,1:nfft/2)));
cep_c  = corrcoef(c_x(:,1:nfft/2));

figure
subplot(121)
imagesc(stft_c, [-1 1]); colorbar; title('STFT \rho')
subplot(122)
imagesc(cep_c, [-1 1]); colorbar; title('Cepstrum \rho')



