function [c cf] = cepstra_mat(x,w,wshft,ncep,nfft,fs)

wlen = length(w);
nwin = fix((length(x)-wlen+wshft)/wshft);

n = 0;
f = 1;

lifter = zeros(1,nfft);
lifter(1:ncep) = 1;
lifter((end-ncep):end) = 1;


c  = zeros(nwin,nfft);
cf = zeros(nwin,nfft);
while n+wlen<=length(x)
  s = x(n+(1:wlen)).*w;
  
  c(f,:)  = ifft(log(abs(fft(s,nfft))));
  cf(f,:) = exp(fft(c(f,:).*lifter,nfft))';
  
  n = n+wshft;
  f = f+1;
end
