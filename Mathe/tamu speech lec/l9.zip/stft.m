function [stft1] = stft(x,w,wshft,nfft)

wlen = length(w);

nwin = fix((length(x)-wlen+wshft)/wshft);

n = 0;
f = 1;
stft1 = zeros(nwin,nfft);
while n+wlen<=length(x)
  s = x(n+(1:wlen)).*w;
  stft1(f,:) = fft(s,nfft);
  n = n+wshft;
  f = f+1;
end
